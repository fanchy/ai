``VanillaALS``
--------------
.. autoclass:: numpy_ml.factorization.VanillaALS
    :members:
    :undoc-members:

``NMF``
--------
.. autoclass:: numpy_ml.factorization.NMF
    :members:
    :undoc-members:
