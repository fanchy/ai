``GMM``
-------

.. autoclass:: numpy_ml.gmm.GMM
	:members:
	:undoc-members:
	:inherited-members:
