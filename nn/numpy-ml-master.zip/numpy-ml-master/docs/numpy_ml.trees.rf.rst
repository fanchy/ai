``RandomForest``
################

.. autoclass:: numpy_ml.trees.RandomForest
	:members:
	:undoc-members:
	:inherited-members:
