Utilities
#########

.. toctree::
   :maxdepth: 3

   numpy_ml.utils.data_structures

   numpy_ml.utils.distance_metrics

   numpy_ml.utils.graphs

   numpy_ml.utils.kernels

   numpy_ml.utils.windows

   numpy_ml.utils.testing
