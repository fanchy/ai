``GradientBoostedDecisionTree``
###############################

.. autoclass:: numpy_ml.trees.GradientBoostedDecisionTree
	:members:
	:undoc-members:
	:inherited-members:
