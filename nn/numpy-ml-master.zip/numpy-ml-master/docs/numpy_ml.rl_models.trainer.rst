Training
========

``Trainer``
-----------

.. automodule:: numpy_ml.rl_models.trainer
    :members:
    :undoc-members:
    :inherited-members:
