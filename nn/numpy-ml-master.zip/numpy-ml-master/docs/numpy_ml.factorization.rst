Matrix factorization
####################

.. toctree::
   :maxdepth: 3

   numpy_ml.factorization.factors
