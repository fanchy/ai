``KNN``
#######

.. autoclass:: numpy_ml.nonparametric.KNN
	:members:
	:undoc-members:
	:inherited-members:
